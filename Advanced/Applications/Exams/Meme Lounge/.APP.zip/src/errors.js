import { html, render } from "./lib.js";

const root = document.getElementById("notifications");

function errorTemplate(message) {
  return html`
    <div @click=${remove} id="errorBox" class="notification">
      <span>${message}</span>
    </div>
  `;
}

export async function showError(message) {
  const notification = errorTemplate(message);
  const subst = document.createElement("div");
  render(notification, subst);
  const el = subst.firstElementChild;
  el.style.display = "inline-block";
  root.appendChild(el);
  setTimeout(remove, 3000);
}

function remove() {
  root.replaceChildren();
}
